package yooj.toyproject.orderbyspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderBySpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
