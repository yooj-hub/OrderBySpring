package yooj.toyproject.orderbyspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderBySpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderBySpringApplication.class, args);
	}

}
